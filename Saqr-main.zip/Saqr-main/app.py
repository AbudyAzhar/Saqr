import streamlit as st
import pandas as pd
import os
import cv2
import time
import numpy as np
from tensorflow.lite.python.interpreter import Interpreter
import predict_plate

# Define the path to the CSV file
csv_file_path = 'stolen_vehicles.csv'

# Function to load the CSV file or create an empty one if it doesn't exist
def load_data():
    if os.path.exists(csv_file_path):
        return pd.read_csv(csv_file_path)
    else:
        return pd.DataFrame(columns=['License Plate'])

# Function to save the data to the CSV file
def save_data(data):
    data.to_csv(csv_file_path, index=False)

# Load existing data
data = load_data()

# Streamlit app
st.title('Stolen Vehicle License Plate Registry')

# Form for entering license plate
with st.form('license_plate_form'):
    license_plate = st.text_input('Enter License Plate')
    submitted = st.form_submit_button('Submit')

    if submitted:
        # Add the new license plate to the data
        new_row = pd.DataFrame({'License Plate': [license_plate]})
        data = pd.concat([data, new_row], ignore_index=True)

        # Save the updated data to the CSV file
        save_data(data)

        st.success(f'License plate {license_plate} added.')

# Display the current data
st.subheader('Registered Stolen Vehicles')
st.write(data)

# Live license plate detection
st.subheader('Live License Plate Detection')

modelpath = 'detect.tflite'
lblpath = 'labelmap.txt'
min_conf = 0.85  # Adjusted minimum confidence to 0.85

# Load the TFLite model and allocate tensors
interpreter = Interpreter(model_path=modelpath)
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
height = input_details[0]['shape'][1]
width = input_details[0]['shape'][2]
float_input = (input_details[0]['dtype'] == np.float32)
input_mean = 127.5
input_std = 127.5

# Load label map
with open(lblpath, 'r') as f:
    labels = [line.strip() for line in f.readlines()]

# Function to process a frame and detect license plates
def process_frame(frame):
    frame_resized = cv2.resize(frame, (width, height))
    if float_input:
        frame_resized = (np.float32(frame_resized) - input_mean) / input_std
    else:
        frame_resized = np.uint8(frame_resized)
    input_data = np.expand_dims(frame_resized, axis=0)

    # Perform inference
    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()

    # Get output data
    boxes = interpreter.get_tensor(output_details[1]['index'])[0]
    classes = interpreter.get_tensor(output_details[3]['index'])[0]
    scores = interpreter.get_tensor(output_details[0]['index'])[0]

    for i in range(len(scores)):
        if (scores[i] > min_conf) and (scores[i] <= 1.0):
            ymin = int(max(1, (boxes[i][0] * frame.shape[0])))
            xmin = int(max(1, (boxes[i][1] * frame.shape[1])))
            ymax = int(min(frame.shape[0], (boxes[i][2] * frame.shape[0])))
            xmax = int(min(frame.shape[1], (boxes[i][3] * frame.shape[1])))

            # Draw bounding box
            cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (10, 255, 0), 2)

            # Crop and process the detected plate
            cropped_plate = frame[ymin:ymax, xmin:xmax]
            plate_characters = predict_plate.get_license_plate(cropped_plate)

            # Check if the detected plate matches the registered stolen vehicles
            if plate_characters in data['License Plate'].values:
                st.warning(f'Detected Stolen Vehicle: {plate_characters}')

            # Draw label
            label = f'{plate_characters}: {int(scores[i] * 100)}%'
            label_size, base_line = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
            label_ymin = max(ymin, label_size[1] + 10)
            cv2.rectangle(frame, (xmin, label_ymin - label_size[1] - 10),
                          (xmin + label_size[0], label_ymin + base_line - 10), (255, 255, 255), cv2.FILLED)
            cv2.putText(frame, label, (xmin, label_ymin - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)

    return frame

# Initialize session state for video capture
if 'video_capture' not in st.session_state:
    st.session_state.video_capture = None
if 'running' not in st.session_state:
    st.session_state.running = False

# Function to start video capture
def start_video():
    if st.session_state.video_capture is None or not st.session_state.video_capture.isOpened():
        st.session_state.video_capture = cv2.VideoCapture(0)
    st.session_state.running = True

# Function to stop video capture
def stop_video():
    if st.session_state.video_capture is not None and st.session_state.video_capture.isOpened():
        st.session_state.video_capture.release()
    st.session_state.running = False

# Buttons for controlling video capture
start_button = st.button('Start', on_click=start_video, key='start_button')
stop_button = st.button('Stop', on_click=stop_video, key='stop_button')

# Display the video stream in Streamlit
frame_placeholder = st.empty()

while st.session_state.running:
    ret, frame = st.session_state.video_capture.read()
    if not ret:
        st.error('Error: Could not read frame from video stream.')
        break

    # Process the frame for license plate detection
    frame = process_frame(frame)

    # Display the processed frame
    frame_placeholder.image(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), channels='RGB')

    # Check if the stop button is pressed
    if not st.session_state.running:
        break

cv2.destroyAllWindows()

# Button for restarting the app
if st.button('Restart', key='restart_button'):
    st.experimental_rerun()
